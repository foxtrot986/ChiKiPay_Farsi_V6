﻿package com.chikipay.ui
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
class MainActivity: AppCompatActivity(){override fun onCreate(b:Bundle?){super.onCreate(b)}}

